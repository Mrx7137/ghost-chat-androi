# GHOST CHAT — Android registration stage

## Что добавлено
- Экран регистрации: почта + пароль.
- Запрос шестизначного кода на почту.
- Экран ввода кода.
- После правильного кода Cloud Function создаёт Firebase Auth аккаунт и возвращает custom token.
- Вход по почте и паролю, выход из аккаунта.
- Код живёт 10 минут; повторная отправка ограничена интервалом 60 секунд; максимум 5 неверных попыток.

## Важно
Это не готовый публичный продукт. Это заготовка регистрации. Чаты, сообщения, группы, файлы, голосовые и звонки ещё не реализованы. Нужны тесты, антиспам, мониторинг и проверка безопасности перед выпуском.

## Требования
- Flutter SDK и Android Studio
- Firebase project с включённым Blaze plan для Cloud Functions (возможны расходы)
- Firebase Authentication, Firestore, Cloud Functions
- SMTP-провайдер для отправки писем (например, свой почтовый SMTP-сервис)
- Android App Check / Play Integrity для релизной сборки

## Подключение Firebase
1. Создайте Firebase project.
2. Установите FlutterFire CLI и выполните `flutterfire configure` в корне проекта. Выберите Android. Команда создаст `lib/firebase_options.dart`.
3. Добавьте в `lib/main.dart` импорт:
   `import 'firebase_options.dart';`
   и замените `await Firebase.initializeApp();` на:
   `await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);`
4. В Firebase Console включите Authentication (Email/Password), Firestore и Cloud Functions.
5. Установите Firebase CLI, войдите и выполните `firebase init` только если требуется связать локальный каталог с вашим проектом. Не перезаписывайте подготовленные файлы `firebase.json` и `firestore.rules`.
6. Установите секреты SMTP в Functions:
   ```
   firebase functions:secrets:set SMTP_HOST
   firebase functions:secrets:set SMTP_PORT
   firebase functions:secrets:set SMTP_USER
   firebase functions:secrets:set SMTP_PASS
   firebase functions:secrets:set MAIL_FROM
   firebase functions:secrets:set CODE_PEPPER
   ```
   Значения берите у своего почтового провайдера. Никогда не добавляйте SMTP-пароль в Flutter-код, Git или этот архив.
7. Включите App Check для Android (Play Integrity) и зарегистрируйте приложение. Для локальной разработки используйте debug provider по официальной инструкции Firebase, не отключайте App Check в релизе.
8. В `functions/` выполните `npm install`, затем `npm run build`.
9. Из корня выполните `firebase deploy --only functions,firestore:rules`.
10. Запустите приложение: `flutter pub get`, затем `flutter run`.

## Примечания безопасности
- Код подтверждения хранится только в виде SHA-256-хеша с отдельным секретным pepper из Firebase Secret Manager, истекает через 10 минут и ограничен по попыткам. Дополнительно для production нужны лимиты по IP/device и защита от массовой рассылки.
- Настройте SMTP SPF/DKIM/DMARC и проверяйте доставку писем.
- Не используйте реальные персональные данные при тестировании без необходимости.
- Нельзя обещать абсолютное отсутствие багов; нужно прогонять тесты на физических Android-устройствах и проверять восстановление доступа, удаление аккаунта и злоупотребления.
- Этот проект не реализует сквозное шифрование. Не называйте его E2EE/защищённым мессенджером.
