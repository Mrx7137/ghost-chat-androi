import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue, Timestamp } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import * as nodemailer from "nodemailer";
import { createHash, randomInt } from "crypto";

initializeApp();
const db = getFirestore();
const SMTP_HOST = defineSecret("SMTP_HOST");
const SMTP_PORT = defineSecret("SMTP_PORT");
const SMTP_USER = defineSecret("SMTP_USER");
const SMTP_PASS = defineSecret("SMTP_PASS");
const MAIL_FROM = defineSecret("MAIL_FROM");
const CODE_PEPPER = defineSecret("CODE_PEPPER");
const CODE_TTL_MS = 10 * 60 * 1000;

function cleanEmail(value: unknown): string {
  if (typeof value !== "string") throw new HttpsError("invalid-argument", "Укажите почту.");
  const email = value.trim().toLowerCase();
  if (email.length > 254 || !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email))
    throw new HttpsError("invalid-argument", "Некорректная почта.");
  return email;
}
function hashCode(email: string, code: string, pepper: string): string {
  return createHash("sha256").update(`${email}:${code}:${pepper}`).digest("hex");
}

export const sendRegistrationCode = onCall(
  { secrets: [SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, MAIL_FROM, CODE_PEPPER], enforceAppCheck: true },
  async (request) => {
    const email = cleanEmail(request.data?.email);
    const existing = await getAuth().getUserByEmail(email).catch(() => null);
    if (existing) throw new HttpsError("already-exists", "Аккаунт с такой почтой уже существует.");
    const ref = db.collection("registrationCodes").doc(createHash("sha256").update(email).digest("hex"));
    const previous = await ref.get();
    const now = Date.now();
    const lastSent = previous.exists ? Number(previous.get("lastSentAt") || 0) : 0;
    if (now - lastSent < 60_000) throw new HttpsError("resource-exhausted", "Запрашивать код можно раз в минуту.");
    const code = String(randomInt(100000, 1000000));
    await ref.set({
      codeHash: hashCode(email, code, CODE_PEPPER.value()),
      expiresAt: Timestamp.fromMillis(now + CODE_TTL_MS),
      lastSentAt: now,
      attempts: 0
    });
    const port = Number(SMTP_PORT.value());
    const transporter = nodemailer.createTransport({
      host: SMTP_HOST.value(), port, secure: port === 465,
      auth: { user: SMTP_USER.value(), pass: SMTP_PASS.value() }
    });
    try {
      await transporter.sendMail({
        from: MAIL_FROM.value(), to: email,
        subject: "Код подтверждения GHOST CHAT",
        text: `Ваш код GHOST CHAT: ${code}\\nКод действует 10 минут. Никому не сообщайте его.`,
        html: `<div style="font-family:Arial;background:#17212b;color:white;padding:28px"><h2>GHOST CHAT</h2><p>Код подтверждения:</p><div style="font-size:32px;font-weight:bold;letter-spacing:8px">${code}</div><p>Код действует 10 минут. Никому не сообщайте его.</p></div>`
      });
    } catch (e) {
      await ref.delete();
      console.error("Email delivery failed", e);
      throw new HttpsError("internal", "Не удалось отправить письмо. Попробуйте позже.");
    }
    return { sent: true, expiresInSeconds: 600 };
  }
);

export const verifyRegistrationCode = onCall(
  { secrets: [CODE_PEPPER], enforceAppCheck: true },
  async (request) => {
    const email = cleanEmail(request.data?.email);
    const code = String(request.data?.code || "");
    const password = request.data?.password;
    if (!/^\\d{6}$/.test(code) || typeof password !== "string" || password.length < 8 || password.length > 128)
      throw new HttpsError("invalid-argument", "Проверьте код и пароль (не менее 8 символов).");

    const ref = db.collection("registrationCodes").doc(createHash("sha256").update(email).digest("hex"));
    const result = await db.runTransaction(async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists) return "missing";
      const data = snap.data()!;
      if (Date.now() > data.expiresAt.toMillis()) {
        tx.delete(ref);
        return "expired";
      }
      if (Number(data.attempts || 0) >= 5) {
        tx.delete(ref);
        return "locked";
      }
      if (data.codeHash !== hashCode(email, code, CODE_PEPPER.value())) {
        tx.update(ref, { attempts: FieldValue.increment(1) });
        return "wrong";
      }
      tx.delete(ref);
      return "ok";
    });
    if (result === "missing" || result === "expired") throw new HttpsError("not-found", "Код не найден или истёк.");
    if (result === "locked") throw new HttpsError("resource-exhausted", "Слишком много попыток. Запросите новый код.");
    if (result === "wrong") throw new HttpsError("permission-denied", "Неверный код.");

    try {
      const user = await getAuth().createUser({ email, password, emailVerified: true });
      const customToken = await getAuth().createCustomToken(user.uid);
      return { customToken };
    } catch (e: any) {
      if (e?.code === "auth/email-already-exists") throw new HttpsError("already-exists", "Аккаунт уже существует.");
      console.error("Account creation failed", e);
      throw new HttpsError("internal", "Не удалось создать аккаунт.");
    }
  }
);
