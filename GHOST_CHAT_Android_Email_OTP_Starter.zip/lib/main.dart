import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';

const bg = Color(0xFF17212B);
const panel = Color(0xFF202B36);
const accent = Color(0xFF3390EC);
const muted = Color(0xFF91A0AE);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GhostChatApp());
}

class GhostChatApp extends StatelessWidget {
  const GhostChatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'GHOST CHAT',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: accent)),
      ),
    ),
    home: const BootstrapScreen(),
  );
}

class BootstrapScreen extends StatefulWidget {
  const BootstrapScreen({super.key});
  @override
  State<BootstrapScreen> createState() => _BootstrapScreenState();
}

class _BootstrapScreenState extends State<BootstrapScreen> {
  bool ready = false;
  String? error;
  @override
  void initState() {
    super.initState();
    _init();
  }
  Future<void> _init() async {
    try {
      await Firebase.initializeApp();
      if (mounted) setState(() => ready = true);
    } catch (_) {
      if (mounted) setState(() => error = 'Firebase пока не настроен. Сначала подключите проект Firebase по инструкции README.');
    }
  }
  @override
  Widget build(BuildContext context) {
    if (ready) return const AuthGate();
    return Scaffold(body: Center(child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const BrandMark(),
        const SizedBox(height: 24),
        if (error == null) const CircularProgressIndicator(),
        if (error != null) Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: muted)),
      ]),
    )));
  }
}

class BrandMark extends StatelessWidget {
  const BrandMark({super.key});
  @override
  Widget build(BuildContext context) => Column(children: [
    Container(width: 76, height: 76, decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(24), border: Border.all(color: accent.withOpacity(.5))),
      child: const Icon(Icons.send_rounded, color: accent, size: 38)),
    const SizedBox(height: 14),
    const Text('GHOST CHAT', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 2)),
    const SizedBox(height: 5),
    const Text('PRIVATE MESSAGING', style: TextStyle(color: muted, fontSize: 10, letterSpacing: 2)),
  ]);
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      if (snapshot.data != null) return const HomeScreen();
      return const AuthScreen();
    },
  );
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final code = TextEditingController();
  bool isRegister = true;
  bool codeSent = false;
  bool busy = false;
  String? error;

  Future<void> _sendCode() async {
    if (!email.text.trim().contains('@')) return _show('Введите корректный адрес почты.');
    if (password.text.length < 8) return _show('Пароль должен содержать минимум 8 символов.');
    setState(() { busy = true; error = null; });
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('sendRegistrationCode');
      await callable.call({'email': email.text.trim().toLowerCase()});
      if (mounted) setState(() => codeSent = true);
    } on FirebaseFunctionsException catch (e) {
      _show(_friendly(e));
    } catch (_) {
      _show('Не удалось отправить код. Проверьте подключение и настройки сервера.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _verifyAndCreate() async {
    if (!RegExp(r'^\d{6}$').hasMatch(code.text.trim())) return _show('Введите шестизначный код из письма.');
    setState(() { busy = true; error = null; });
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('verifyRegistrationCode');
      final result = await callable.call({
        'email': email.text.trim().toLowerCase(),
        'code': code.text.trim(),
        'password': password.text,
      });
      final token = result.data['customToken'] as String?;
      if (token == null || token.isEmpty) throw Exception('No custom token');
      await FirebaseAuth.instance.signInWithCustomToken(token);
    } on FirebaseFunctionsException catch (e) {
      _show(_friendly(e));
    } catch (_) {
      _show('Не удалось создать аккаунт. Попробуйте ещё раз.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _login() async {
    if (!email.text.trim().contains('@') || password.text.isEmpty) return _show('Введите почту и пароль.');
    setState(() => busy = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim().toLowerCase(), password: password.text);
    } on FirebaseAuthException catch (e) {
      _show(e.code == 'user-not-found' || e.code == 'wrong-password' || e.code == 'invalid-credential'
        ? 'Неверная почта или пароль.' : 'Не удалось войти: ${e.message ?? e.code}');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _friendly(FirebaseFunctionsException e) {
    switch (e.code) {
      case 'already-exists': return 'Аккаунт с такой почтой уже существует. Попробуйте войти.';
      case 'not-found': return 'Код не найден или срок его действия истёк. Запросите новый.';
      case 'permission-denied': return 'Неверный код. Проверьте письмо и попробуйте снова.';
      case 'resource-exhausted': return 'Слишком много попыток. Подождите и попробуйте позже.';
      case 'invalid-argument': return e.message ?? 'Проверьте введённые данные.';
      default: return e.message ?? 'Ошибка сервера. Попробуйте позже.';
    }
  }

  void _show(String value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  @override
  void dispose() { email.dispose(); password.dispose(); code.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Center(child: BrandMark()),
        const SizedBox(height: 38),
        Text(isRegister ? (codeSent ? 'ПОДТВЕРЖДЕНИЕ ПОЧТЫ' : 'СОЗДАТЬ АККАУНТ') : 'С ВОЗВРАЩЕНИЕМ',
          textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: 1.3)),
        const SizedBox(height: 8),
        Text(isRegister ? (codeSent ? 'Мы отправили шестизначный код на вашу почту.' : 'Укажите почту и придумайте пароль.') : 'Войдите в свой аккаунт GHOST CHAT.',
          textAlign: TextAlign.center, style: const TextStyle(color: muted)),
        const SizedBox(height: 24),
        TextField(controller: email, enabled: !codeSent, keyboardType: TextInputType.emailAddress, autocorrect: false,
          decoration: const InputDecoration(labelText: 'Электронная почта', prefixIcon: Icon(Icons.mail_outline))),
        const SizedBox(height: 12),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Пароль (минимум 8 символов)', prefixIcon: Icon(Icons.lock_outline))),
        if (isRegister && codeSent) ...[
          const SizedBox(height: 12),
          TextField(controller: code, keyboardType: TextInputType.number, maxLength: 6,
            decoration: const InputDecoration(labelText: 'Код из письма', prefixIcon: Icon(Icons.verified_user_outlined), counterText: '')),
        ],
        const SizedBox(height: 18),
        FilledButton(
          onPressed: busy ? null : () {
            if (!isRegister) { _login(); }
            else if (!codeSent) { _sendCode(); }
            else { _verifyAndCreate(); }
          },
          style: FilledButton.styleFrom(backgroundColor: accent, minimumSize: const Size.fromHeight(52)),
          child: busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
            : Text(!isRegister ? 'ВОЙТИ' : (codeSent ? 'ПОДТВЕРДИТЬ И СОЗДАТЬ АККАУНТ' : 'ПОЛУЧИТЬ КОД')),
        ),
        if (isRegister && codeSent) TextButton(onPressed: busy ? null : () { setState(() { codeSent = false; code.clear(); }); }, child: const Text('Изменить почту')),
        const SizedBox(height: 8),
        TextButton(onPressed: busy ? null : () => setState(() { isRegister = !isRegister; codeSent = false; }),
          child: Text(isRegister ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Зарегистрироваться')),
        const SizedBox(height: 12),
        const Text('Не сообщайте никому код подтверждения и пароль.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 11)),
      ])),
    ))),
  );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('GHOST CHAT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
        actions: [IconButton(onPressed: () async => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
      body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const BrandMark(), const SizedBox(height: 26),
        const Text('Аккаунт создан', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(user?.email ?? '', style: const TextStyle(color: muted)),
        const SizedBox(height: 18),
        const Text('Это следующий этап разработки. После настройки чатов здесь появится список переписок.',
          textAlign: TextAlign.center, style: TextStyle(color: muted)),
      ]))),
    );
  }
}
